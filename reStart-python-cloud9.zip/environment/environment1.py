# myString = "This is a string."
# print(myString)
# print(type(myString))
# print(myString + " is of data type " + str(type(myString)))
# fstring = "water"
# sstring = "fall"
# tstring = fstring + sstring
# print(tstring)
# name = input("What is your name? ")
# print(name)
# color = input("what is your favorite color? ")
# animal = input("what is yout favorite animal? ")
# print("{}, you like a {} {}!".format(name,color,animal))
# myFruitList = ["apple","banana","cherry"]
# print(myFruitList)
# print(type(myFruitList))

# print(myFruitList[0])
# print(myFruitList[1])
# print(myFruitList[2])

# # changing the values in a list

# myFruitList[2] = "orange"

# print(myFruitList)

# # INTRODUICNG A TUPLE DATATYPE
# myFinalAnswerTuple = ("apple", "banana", "pineapple")
# print(myFinalAnswerTuple)
# print(type(myFinalAnswerTuple))

# # accesing tuple position
# print(myFinalAnswerTuple[0])
# print(myFinalAnswerTuple[1])
# print(myFinalAnswerTuple[2])

# # introducing the dictionary data type

# myFavouriteFruitDictionary = {
#     "Akua" : "apple",
#     "saanvi" : "banana",
#     "Paulo" : "pineapple"
# }

# print(myFavouriteFruitDictionary)
# print(type(myFavouriteFruitDictionary))

# # accessing a dictionary by name

# print(myFavouriteFruitDictionary["Akua"])
# print(myFavouriteFruitDictionary["saanvi"])
# print(myFavouriteFruitDictionary["Paulo"])

# creating mixed-type list

# myMixedTypeList = [45, 290578, 1.02, True, "My dog is on the bed.", "45"]

# for item in myMixedTypeList:
    
#     print("{} is of the data type {}".format(item,type(item)))

# ## composite  data types

# import csv
# import copy

# myVehicle = {
#     "vin" : "<empty>",
#     "make" : "<empty>",
#     "model" : "<empty>",
#     "year" : 0,
#     "range" : 0,
#     "topSpeed": 0,
#     "zeroSixty" : 0.0,
#     "mileage" : 0
# }

# myInventoryList = []

# for key, value in myVehicle.items():
#     print("{} : {}".format(key,value))
    
# with open('car_fleet.csv') as csvfile:
#     csvReader = csv.reader(csvfile, delimiter=',')
#     lineCount = 0
    
#     for row in csvReader:
#         if lineCount ==0:
#             print(f'Column names are: {",".join(row)}')
#             lineCount +=1
            
#         else:  
#             print(f'vin: {row[0]} make: {row[1]}, model: {row[2]}, year: {row[3]}, range: {row[4]}, topSpeed: {row[5]}, zeroSixty: {row[6]}, mileage: {row[7]}')  
#             currentVehicle = copy.deepcopy(myVehicle)  
#             currentVehicle["vin"] = row[0]  
#             currentVehicle["make"] = row[1]  
#             currentVehicle["model"] = row[2]  
#             currentVehicle["year"] = row[3]  
#             currentVehicle["range"] = row[4]  
#             currentVehicle["topSpeed"] = row[5]  
#             currentVehicle["zeroSixty"] = row[6]  
#             currentVehicle["mileage"] = row[7]  
#             myInventoryList.append(currentVehicle)  
#             lineCount += 1  
#     print(f'Processed {lineCount} lines.')
    
#     for myCarProperties in myInventoryList:
#         for key, value in myCarProperties.items():
#             print("{} : {}".format(key,value))
#             print("-----")

# # working with the if statement

# userReply = input("Do you need the ship a package? (Enter yes or no) ")
# if  userReply == "yes":
#     print("We can help you ship that package!")
    
# else:
#     print("Please come back when you need to ship a package. Thank you.")
    
# userReply = input("Would you like to buy stamps, buy an envelope, or make a copy? (Enter stamps, envelope, or copy) ")
# if  userReply == "stamps":
#     print("We have many stamp designs to choose from.")
    
# elif userReply == "envelope":
#     print("We ahve many envelope sizes to chose from.")
    
# elif userReply == "copy":
#     copies = input("How many copies would you like? (Enter a number) ")
#     print("Here are {} copies.".format(copies))
    
# else:
#     print("Thank you, please come again.")  

# working with loops
print("Welcome to guess the Number!")
print("The rules are simple. I will think of a number, and you will try to guess it.")

import random

number = random.randint (1,10)

isGuessRight = False

while isGuessRight !=True:
    guess = input("Guess a number between 1 and 10:")
    if int(guess) == number:
        print("You guessed {}. That is correct! You WIN!".format(guess))
        isGuessRight = True
    else:
        print("You guessed {}. Sorry, that isn't it. Try again.".format(guess))